package com.example.finanzaspersonales

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.rememberNavController
import androidx.compose.runtime.livedata.observeAsState
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.material3.*
import androidx.compose.runtime.*

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewModel = ViewModelProvider(this)[LoginViewModel::class.java]

        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val loginButton = findViewById<Button>(R.id.loginButton)

        viewModel.loginSuccess.observe(this) { success ->
            if (success) {
                // ✅ Aplicamos tema dinámico desde aquí
                setContent {
                    val darkThemeViewModel: DarkThemeViewModel = viewModel()
                    val isDarkTheme by darkThemeViewModel.isDarkTheme.observeAsState(false)

                    MaterialTheme(
                        colorScheme = if (isDarkTheme) darkColorScheme() else lightColorScheme()
                    ) {
                        val navController = rememberNavController()
                        AppNavGraph(navController = navController)
                    }
                }
            } else {
                passwordEditText.error = "Correo o contraseña incorrectos"
            }
        }

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()
            viewModel.login(email, password)
        }
    }
}
