package com.example.finanzaspersonales

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SalarioViewModel : ViewModel() {

    private val _salario = MutableLiveData<Float>()
    val salario: LiveData<Float> = _salario

    fun guardarSalario(valor: Float) {
        _salario.value = valor
    }
    fun restarGasto(gasto: Float) {
        val actual = _salario.value ?: 0f
        _salario.value = actual - gasto
    }

}
