package com.example.finanzaspersonales

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController


data class CategoriaGasto(
    val nombre: String,
    val descripcion: String,
    val imagenResId: Int
)

@Composable
fun DetallesScreen(
    navController: NavHostController,
    salarioViewModel: SalarioViewModel,
    gastosViewModel: GastosViewModel
) {
    var searchQuery by remember { mutableStateOf("") }
    val seleccionadas by gastosViewModel.categoriasSeleccionadas.observeAsState(emptyList())
    val salario by salarioViewModel.salario.observeAsState()
    var mostrarDialogo by remember { mutableStateOf(false) }

    val categorias = listOf(
        CategoriaGasto("Alimentación", "Gastos en comida y bebidas", R.drawable.ic_food),
        CategoriaGasto("Transporte", "Movilidad y transporte público", R.drawable.ic_transport),
        CategoriaGasto("Educación", "Libros, matrícula, cursos", R.drawable.ic_education),
        CategoriaGasto("Entretenimiento", "Cine, juegos, eventos", R.drawable.ic_entertainment),
        CategoriaGasto("Salud", "Medicinas y servicios médicos", R.drawable.ic_health)
    )

    val containerColor = MaterialTheme.colorScheme.background

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(containerColor)
            .padding(16.dp)
    ) {

        Text(
            text = "Salario mensual: ${salario?.let { "$it" } ?: "No registrado"}",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // 🔍 Barra de búsqueda
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Buscar categorías") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 🔘 Botones
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(onClick = {
                    navController.navigate("ingresos")
                }) {
                    Text("Ingresos")
                }
                Button(onClick = {
                    mostrarDialogo = true
                }) {
                    Text("Gastos")
                }
                Button(onClick = { searchQuery = "" }) {
                    Text("Explorar")
                }
            }
            Button(
                onClick = { navController.navigate("configuracion") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Configuración")
            }
        }

        if (mostrarDialogo) {
            AlertDialog(
                onDismissRequest = { mostrarDialogo = false },
                confirmButton = {
                    TextButton(onClick = { mostrarDialogo = false }) {
                        Text("Cerrar")
                    }
                },
                title = { Text("Categorías seleccionadas") },
                text = {
                    if (seleccionadas.isEmpty()) {
                        Text("No has seleccionado ninguna categoría aún.")
                    } else {
                        Column {
                            seleccionadas.forEach { Text("• $it") }
                        }
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 📟 Lista de categorías tipo tarjeta
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val categoriasFiltradas = categorias.filter {
                it.nombre.contains(searchQuery, ignoreCase = true)
            }
            items(categoriasFiltradas) { categoria ->
                CategoriaCard(categoria) {
                    navController.navigate("categoriaDetalle/${categoria.nombre}")
                }
            }
        }
    }
}

@Composable
fun CategoriaCard(categoria: CategoriaGasto, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(4.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp)) {
            Image(
                painter = painterResource(id = categoria.imagenResId),
                contentDescription = categoria.nombre,
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Text(categoria.nombre, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(categoria.descripcion, fontSize = 14.sp)
            }
        }
    }
}
