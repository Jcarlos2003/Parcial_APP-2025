package com.example.finanzaspersonales

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import android.content.Context
import android.content.SharedPreferences

class DarkThemeViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs: SharedPreferences =
        application.getSharedPreferences("config", Context.MODE_PRIVATE)

    private val _isDarkTheme = MutableLiveData<Boolean>(prefs.getBoolean("dark_theme", false))
    val isDarkTheme: LiveData<Boolean> = _isDarkTheme

    fun toggleDarkTheme(enabled: Boolean) {
        _isDarkTheme.value = enabled
        prefs.edit().putBoolean("dark_theme", enabled).apply()
    }
}
