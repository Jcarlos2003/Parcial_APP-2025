package com.example.finanzaspersonales

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class GastosViewModel : ViewModel() {

    private val _categoriasSeleccionadas = MutableLiveData<List<String>>(emptyList())
    val categoriasSeleccionadas: LiveData<List<String>> = _categoriasSeleccionadas

    fun seleccionarCategoria(nombre: String) {
        val actual = _categoriasSeleccionadas.value ?: emptyList()
        if (!actual.contains(nombre)) {
            _categoriasSeleccionadas.value = actual + nombre
        }
    }
}
