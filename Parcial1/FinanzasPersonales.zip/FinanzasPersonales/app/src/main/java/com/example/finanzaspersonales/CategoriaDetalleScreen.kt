package com.example.finanzaspersonales

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun CategoriaDetalleScreen(
    categoriaNombre: String,
    navController: NavHostController,
    viewModel: GastosViewModel,
    salarioViewModel: SalarioViewModel
) {
    var input by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text(
            text = "Categoría: $categoriaNombre",
            style = MaterialTheme.typography.headlineMedium
        )

        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Monto del gasto") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                val gasto = input.toFloatOrNull()
                if (gasto != null && gasto > 0) {
                    viewModel.seleccionarCategoria(categoriaNombre)
                    salarioViewModel.restarGasto(gasto)
                    Toast.makeText(context, "Gasto registrado", Toast.LENGTH_SHORT).show()
                    navController.popBackStack()
                } else {
                    Toast.makeText(context, "Ingresa un valor válido", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Registrar gasto y volver")
        }
    }
}
