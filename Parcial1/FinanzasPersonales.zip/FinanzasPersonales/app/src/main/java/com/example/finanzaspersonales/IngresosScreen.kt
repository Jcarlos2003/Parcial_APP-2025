package com.example.finanzaspersonales

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import android.widget.Toast

@Composable
fun IngresosScreen(
    salarioViewModel: SalarioViewModel = viewModel(),
    onSalarioGuardado: () -> Unit
) {
    var input by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Ingresa tu salario mensual", style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Salario") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                val valor = input.toFloatOrNull()
                if (valor != null && valor > 0) {
                    salarioViewModel.guardarSalario(valor)
                    Toast.makeText(context, "Salario guardado", Toast.LENGTH_SHORT).show()
                    onSalarioGuardado()
                } else {
                    Toast.makeText(context, "Ingresa un valor válido", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Guardar")
        }
    }
}
