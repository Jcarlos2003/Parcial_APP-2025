package com.example.finanzaspersonales

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.NavType
import androidx.navigation.navArgument
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun AppNavGraph(navController: NavHostController) {
    val salarioViewModel: SalarioViewModel = viewModel()
    val gastosViewModel: GastosViewModel = viewModel()
    val darkThemeViewModel: DarkThemeViewModel = viewModel()

    NavHost(navController = navController, startDestination = "detalles") {

        composable("detalles") {
            DetallesScreen(
                navController = navController,
                salarioViewModel = salarioViewModel,
                gastosViewModel = gastosViewModel
            )
        }

        composable("ingresos") {
            IngresosScreen(
                salarioViewModel = salarioViewModel,
                onSalarioGuardado = {
                    navController.popBackStack()
                }
            )
        }

        composable(
            route = "categoriaDetalle/{nombre}",
            arguments = listOf(navArgument("nombre") { type = NavType.StringType })
        ) { backStackEntry ->
            val nombre = backStackEntry.arguments?.getString("nombre") ?: ""
            CategoriaDetalleScreen(
                categoriaNombre = nombre,
                navController = navController,
                viewModel = gastosViewModel,
                salarioViewModel = salarioViewModel
            )
        }

        // 🆕 Ruta para la pantalla de configuración
        composable("configuracion") {
            ConfiguracionScreen(viewModel = darkThemeViewModel)
        }
    }
}
